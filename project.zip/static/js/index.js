import React, { useState } from 'react';
import ReactDOM from 'react-dom';

import { ProductPrice } from './components/ProductPrice';
import { ShoppingCart } from './components/ShoppingCart';
import { Index } from './components/comment';
document.addEventListener('DOMContentLoaded', (event) => {
  if (document.getElementById('product_price')) {
    const element = document.getElementById('product_price');
    const productId = element.dataset.productId;
    ReactDOM.render(<ProductPrice id={ productId } />, element);
  }

  if (document.getElementById('shopping_cart')) {
    ReactDOM.render(<ShoppingCart />, document.getElementById('shopping_cart'));
  }
  if (document.getElementById('product_comment')) {
    ReactDOM.render(<Index />, document.getElementById('product_comment'));
  }

});
