import React, { Component,useState, useEffect } from 'react'

export class Index extends Component{
    constructor(props) {
        super(props);
        this.state={
            comment: [ ],
			data2 : [
					{   title: '父级菜单1',
						key: '/home',
						children: [
							{  title: '二级菜单1',
								key: '/home/m1',
							},
							{ title: '二级菜单2',
								key: '/home/m2',
							}
							]
					},
					{   title: '父级菜单2',
						key: '/login',
						children: [
						{  title: '二级菜单3',
							key: '/login/m3',
						},
						{   title: '二级菜单4',
							key: '/login/m4',
						}
						  ]
					} ]
        }
		this.renderMenu.bind(this)
    }

	componentWillMount(){
      fetch('https://tn9lxb26j2.execute-api.us-east-1.amazonaws.com/items')
        .then(response => response.json())
        .then(data => {
          // 将 API 返回的内容设置到state
          this.setState({comment: data["Items"]});
        });
	}

    renderMenu(data){
		console.log("sfas")
        return (
			data.map((item)=>{
				if (item.comments && item.comments.length!=0) {  //如果有子节点，继续递归调用，直到没有子节点
					return (
						<div key={item.comment_id}>
							{item.comment}
							{item.email}
							{renderMenu(item.comments)}
						</div>
					)
				}
				//没有子节点就返回当前的父节点
				return (
				<div key={item.comment_id}>
					{item.comment}
					{item.email}
				</div>
				)
			})
		)
    }
	
	
	
    render() {
        //传进来的对象是data
		var res=this.renderMenu(this.state.comment)
		return (
			<div>
			{res}
			</div>
		)
	}

}