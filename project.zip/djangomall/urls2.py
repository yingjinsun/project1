"""djangomall URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, re_path,include
from django.conf.urls.i18n import i18n_patterns
from django.template.response import TemplateResponse
from django.contrib.auth import views
from django.utils.translation import gettext_lazy as _
from django.conf.urls.static import static
from django.conf import settings
from django.contrib.auth import views, forms as auth_forms
from django import forms

class AuthenticationFormExample(auth_forms.AuthenticationForm):
    username = forms.EmailField(
        min_length=6,
        widget=forms.EmailInput(
            attrs={'class': 'form-control'}
        )
    )
    password = forms.CharField(
        label=_("Password"),
        widget=forms.PasswordInput(attrs={'class': 'form-control'})
    )

class NewLoginView(views.LoginView):
    template_name = 'accounts/login.html'
    # 表单改成 AuthenticationFormExample
    form_class = AuthenticationFormExample
	
	
urlpatterns = i18n_patterns(
    path('admin/', admin.site.urls),#
    # /accounts/login/ 转给 NewLoginView 处理
    #path('accounts/login/', NewLoginView.as_view()),
    # 把 auth.urls 读取到 accounts/
	path('accounts/', include('accounts.urls')),#
    path('accounts/', include('django.contrib.auth.urls')),#
	path('products/', include(('products.urls', 'products'), namespace='products')),#
	path('api/', include(('api.urls','api'),namespace='api')),#
	path('carts/', __import__('carts').views.index),#
	path('orders/', include(('orders.urls', 'orders'), namespace='orders')),#
    prefix_default_language=False
)

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)