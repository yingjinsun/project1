import os
import django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "backend22.settings")

django.setup()
from main.models import course,tagForMav,category,tagForClass,courseForClass,tagForBootcamp,courseForBootCamp,loupluscard
import json
f = open(r'D:\project\backend2\backend2\lou.json',encoding='utf8')
json_data = json.load(f)
for each in json_data:
	item=loupluscard(**each)
	item.save()
	