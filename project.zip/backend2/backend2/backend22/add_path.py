import os
import django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "backend22.settings")

django.setup()
from main.models import course,tagForMav,category,tagForClass,courseForClass,tagForBootcamp,courseForBootCamp,loupluscard,pathcard
import json
f = open(r'D:\project\backend2\backend2\path.json',encoding='utf8')
json_data = json.load(f)
for each in json_data:
	item=pathcard(**each)
	item.save()
	