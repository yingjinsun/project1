import os
import django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "backend22.settings")

django.setup()
from main.models import course,tagForMav,category,tagForClass,courseForClass,tagForBootcamp,courseForBootCamp,loupluscard,classify,recommendcourse
import json
f = open(r'D:\project\backend2\backend2\classify.json',encoding='utf8')
json_data = json.load(f)
ii=1
for each in json_data:
	item_recommend_course=recommendcourse(**each['recommend_course'])
	item_recommend_course.save()
	_courses=[]
	for ea_course in each['courses']:
		item_course=course(**ea_course)
		item_course.save()
		_courses.append(item_course)
	item_classify=classify(id=ii,classify_name=each['classify_name'],description=each['description'],recommend_course=item_recommend_course)

	item_classify.save()
	
	for ea_course in _courses:
		item_classify.course.add(ea_course)
	item_classify.save()
	ii+=1