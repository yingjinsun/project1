from django.db import models

# Create your models here.
class  lab (models.Model):
	id = models.IntegerField(primary_key=True)
	name = models.CharField(max_length=256, blank=True)
	parent_id=models.IntegerField(default=0)