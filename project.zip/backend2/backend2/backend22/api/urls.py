from django.urls import path
#from . import views
from main.views import classficationCourses,classifyAPIView,courseAPIView
from questions.views import questionAPIView,mptt,answerAPIView
from rest_framework.routers import DefaultRouter

# Create your views here.
urlpatterns = [

  path('v2/index/classfication-courses/', classifyAPIView.as_view(), name='classficationCourses'),
  path('v2/courses/<id>/', courseAPIView.as_view(), name='course'),
  path('v2/question/<id>/', questionAPIView.as_view({'get': 'retrieve'}), name='question'),
  path('v2/question/<id>/answers', questionAPIView.as_view({'get': 'answers'}), name='question'),
  #path('v2/question/<id>/answers', mptt, name='answer'),
  #path('v2/question/<id>/answers',answerAPIView.as_view(), name='answer'),
]



