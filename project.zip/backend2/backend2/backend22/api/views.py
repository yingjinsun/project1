from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt

import re
import json
import sys
import main.models
import requests

# Create your views here.
baseUrl = "https://www.shiyanlou.com/api/v2/"
def indexBanner(request):
    content = requests.get("{baseUrl}index/banner-pictures/".format(baseUrl=baseUrl))
    return JsonResponse(content.json(), safe=False)

