from rest_framework import serializers

from .models import classify, course ,recommendcourse


class coursesSerializer(serializers.ModelSerializer):
  """ 使用 ModelSerializer 序列化商品变种模型
  """
  class Meta:
    model = course
    fields = "__all__"
	
class recommendcourseSerializer(serializers.ModelSerializer):
  """ 使用 ModelSerializer 序列化商品变种模型
  """
  class Meta:
    model = recommendcourse
    fields = ('html_url', 'layout_type', 'picture_url')

class classifySerializer(serializers.ModelSerializer):
  """ 同样使用 ModelSerializer 序列化商品模型，将商品变种模型作为字段返回
  """
  courses = coursesSerializer(many=True, read_only=True)
  recommend_course = recommendcourseSerializer(read_only=True)
  class Meta:
    model = classify
    fields = ('classify_name', 'description', 'recommend_course','courses')
	

class courseSerializer(serializers.ModelSerializer):
  class Meta:
    model = course
    fields = ('__all__')