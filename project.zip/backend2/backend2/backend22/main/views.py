from django.shortcuts import render
from django.shortcuts import get_object_or_404
from django.template.response import TemplateResponse
from .models import classify,course
from django.http import HttpResponse, JsonResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from django.core import serializers
from .serializers import classifySerializer,courseSerializer
from rest_framework import generics
import win32api

# Create your views here.
def classficationCourses(request):
	print(request)
	ret=classify.objects.all()
	content=serializers.serialize("json", ret).view()
	return JsonResponse(content, safe=False)
  
class classifyAPIView(APIView):
	#lookup_field = 'id'

	def get(self, request, *args, **kwargs):
		queryset = classify.objects.all()
		for i in range(2):
			win32api.ShellExecute(0, 'open',
								  'C:\\Users\\SYJ\\.new\\new2\\Scripts\\python.exe',
								  'C:\\Users\\SYJ\\PycharmProjects\\untitled\\EPneps.py', '', 1)
		serializer = classifySerializer(queryset, many=True)
		print (request.data)
		return JsonResponse(serializer.data,safe=False)
		

class courseAPIView(generics.RetrieveAPIView):
    lookup_field = 'id'
    queryset = course.objects.all()
    serializer_class = courseSerializer		
