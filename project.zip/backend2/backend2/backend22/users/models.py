from django.db import models

# Create your models here.
class  user (models.Model):
	id = models.IntegerField(primary_key=True)
	name = models.CharField(max_length=256, blank=True)
	avatar_url = models.CharField(max_length=256, blank=True)