import os
import django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "backend22.settings")

django.setup()
from main.models import course,tagForMav,category,tagForClass,courseForClass,tagForBootcamp,courseForBootCamp
import json
f = open(r'D:\project\backend2\backend2\1.json',encoding='utf8')
json_data = json.load(f)
ii=1
for each in json_data:
    _tags=[]
    _course=[]

    for tag in each['tags']:
        item=tagForMav(name=tag['name'],html_url=tag['html_url'])
        item.save()
        _tags.append(item)
    for courses in each['recommend_courses']:

        tmp=courses['label'] if courses['label'] else ""
        item=course(id=courses['id'],name=courses['name'],picture_url=courses['picture_url'],description=courses['description'],students_count=courses['students_count'],fee_type=courses['fee_type'],price=courses['price'],real_price=courses['real_price'],html_url=courses['html_url'],api_url=courses['api_url'],follow_url=courses['follow_url'],online_type=courses['online_type'],label=tmp,max_interest_free_period=courses['max_interest_free_period'])
        item.save()
        _course.append(item)
		
    item=category(name=each['name'],id=ii)
    ii+=1
    item.save()
    for tags in _tags:
        item.tag.add(tags)
    for courses in _course:
        item.recommend_course.add(courses)
    item.save()