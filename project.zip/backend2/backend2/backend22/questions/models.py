from django.db import models
from users.models import user as author
from labs.models import lab
from mptt.models import MPTTModel
from mptt.managers import TreeManager
# Create your models here.
class  question (models.Model):
	id = models.IntegerField(primary_key=True)
	content = models.CharField(max_length=500, blank=True)
	author = models.ForeignKey(author, related_name='author_courses',on_delete=models.CASCADE)
	title = models.CharField(max_length=256, blank=True)
	lab = models.ForeignKey(lab, related_name='lab_courses',on_delete=models.CASCADE)

class answer (MPTTModel, models.Model):
	id = models.IntegerField(primary_key=True)
	content = models.CharField(max_length=500, blank=True)
	relatedQUestion = models.ForeignKey(question, related_name='related_answers',on_delete=models.CASCADE)
	author = models.ForeignKey(author, related_name='author_answers',on_delete=models.CASCADE)
	parent=models.ForeignKey("self", related_name='children',on_delete=models.CASCADE,null=True,blank = True)
	tree = TreeManager()
	def getQid():
		return self.relatedQUestion.id