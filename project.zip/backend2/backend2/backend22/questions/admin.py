from django.contrib import admin
# Register your models here.
from .models import question,answer
from mptt.admin import MPTTModelAdmin

admin.site.register(question)
admin.site.register(answer,MPTTModelAdmin)