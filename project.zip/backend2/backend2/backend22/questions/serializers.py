from rest_framework import serializers

from labs.models import lab as _lab
from users.models import user
from .models import question,answer

class labSerializer(serializers.ModelSerializer):
  """ 使用 ModelSerializer 序列化商品变种模型
  """
  class Meta:
    model = _lab
    fields = "__all__"
	
class authorSerializer(serializers.ModelSerializer):
  """ 使用 ModelSerializer 序列化商品变种模型
  """
  class Meta:
    model = user
    fields = "__all__"

class questionSerializer(serializers.ModelSerializer):
  """ 同样使用 ModelSerializer 序列化商品模型，将商品变种模型作为字段返回
  """
  author = authorSerializer( read_only=True)
  lab = labSerializer(read_only=True)
  class Meta:
    model = question
    fields = ('id', 'content', 'author','title','lab')
	

class answerSerializer(serializers.ModelSerializer):
  relatedQUestion=questionSerializer( read_only=True)
  author =authorSerializer( read_only=True)
  parent=authorSerializer( read_only=True)
  class Meta:
    model = answer
    fields = ('id', 'content', 'relatedQUestion','author','parent')
