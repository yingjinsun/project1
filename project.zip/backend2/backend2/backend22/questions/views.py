from django.shortcuts import render
from django.shortcuts import get_object_or_404
from django.template.response import TemplateResponse
from .models import question,answer
from django.http import HttpResponse, JsonResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from django.core import serializers
from .serializers import labSerializer,authorSerializer,questionSerializer,answerSerializer
from rest_framework import generics
from rest_framework.decorators import action
import django_filters
from rest_framework.viewsets import ModelViewSet
# Create your views here.


from django.shortcuts import render

def mptt(request,id):
	print(id)
	nodes=answer.objects.filter(relatedQUestion_id=id)
	nodes = answer.tree.all()
	print(nodes[0])
	return render(request,'mptt.html', {'nodes': nodes})

class answerAPIView(generics.RetrieveAPIView):
	lookup_field = 'getQid'
	queryset = answer.objects.all()
	serializer_class = answerSerializer
	
'''
class questionAPIView(ModelViewSet):
	lookup_field = 'id'
	queryset = question.objects.all()
	serializer_class = questionSerializer
	@action(detail=False, url_path='answers', methods=['get'] )
	def answers(self, request,id=None):
		qs = self.get_object().related_answers.all()
		serializer = answerSerializer(qs, many=True)

		return JsonResponse(serializer.data,safe=False)
'''
class questionAPIView(ModelViewSet):
	
	lookup_field = 'id'
	queryset = question.objects.all()
	serializer_class = questionSerializer
	@action(detail=False, url_path='answers', methods=['get'] )
	def answers(self, request,id=None):
		qs = self.get_object().related_answers.all()
		#serializer = answerSerializer(qs, many=True)
		def display(answers):
			display_list=[]
			for answer in answers:
				display_list.append(answerSerializer(answer).data)
				children=answer.children.all()
				if len(children)>0:
					display_list.append(display(children))
			return display_list
		root=qs.filter(parent__isnull=True)
		for each in root:
			print(each.id)
		ans=display(root)
		return Response(ans)