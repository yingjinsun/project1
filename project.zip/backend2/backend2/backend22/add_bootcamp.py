import os
import django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "backend22.settings")

django.setup()
from main.models import course,tagForMav,category,tagForClass,courseForClass,tagForBootcamp,courseForBootCamp,loupluscard,classify,recommendcourse
import json
f = open(r'D:\project\backend2\backend2\boot.json',encoding='utf8')
json_data = json.load(f)
ii=1
for each in json_data:
	_tags=[]
	for _tag in each['tags']:
		print(each['tags'])
		_tag=tagForBootcamp(tag=_tag,id=ii)
		_tag.save()
		_tags.append(_tag)
		ii+=1
	each.pop('tags')
	item=courseForBootCamp(**each)
	item.save()
	for _tag in _tags:
		print(_tag)
		item.tags.add(_tag)
	item.save()
	_tags.clear()
	ii+=1
		