from django.contrib import admin

# Register your models here.
from .models import course,tagForMav,category,tagForClass,courseForClass,tagForBootcamp,courseForBootCamp,loupluscard


admin.site.register([course,tagForMav,category,tagForClass,courseForClass,tagForBootcamp,courseForBootCamp,loupluscard])