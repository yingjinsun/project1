from django.db import models


class  course (models.Model):
	api_url = models.CharField(max_length=256, blank=True)
	description = models.CharField(max_length=256, blank=True)
	fee_type = models.CharField(max_length=256, blank=True)
	follow_url = models.CharField(max_length=256, blank=True)
	html_url = models.CharField(max_length=256, blank=True)
	id = models.IntegerField(primary_key=True)
	label = models.CharField(max_length=256,blank=True)
	max_interest_free_period = models.IntegerField(default=0)
	name = models.CharField(max_length=256, blank=True)
	online_type = models.CharField(max_length=256, blank=True)
	picture_url = models.CharField(max_length=256, blank=True)
	price = models.IntegerField(default=0)
	real_price = models.IntegerField(default=0)
	students_count = models.IntegerField(default=0)
	def __str__(self):
		return '{0}'.format(self.name)


class tagForMav (models.Model):
	html_url = models.CharField(max_length=256, blank=True)
	name = models.CharField(max_length=256, blank=True)
	def __str__(self):
		return '{0}'.format(self.name)


# Create your models here.
class  category (models.Model):
	name = models.CharField(max_length=256, blank=True)
	recommend_course=models.ManyToManyField(course, related_name='category_recommend_course')
	tag=models.ManyToManyField(tagForMav, related_name='category_tag')
	
	def __str__(self):
		return '{0}'.format(self.name)
		
		
class tagForClass(models.Model):
	tag = models.CharField(max_length=256, blank=True)

class courseForClass(course):
# Create your models here.
	tag=models.ManyToManyField(tagForClass, related_name='courses_tag')
	
	
class tagForBootcamp(models.Model):
	tag = models.CharField(max_length=256, blank=True)

class courseForBootCamp(course):
	tag=models.ManyToManyField(tagForBootcamp, related_name='courses_tag')