from django.test import TestCase

# Create your tests here.
class CartsViewTests(TestCase):
    def test_carts(self):
        r = self.client.get('/carts/')
        self.assertEqual(r.status_code, 200)