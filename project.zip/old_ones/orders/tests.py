from django.test import TestCase

from .models import Order

class OrderModelTests(TestCase):
    def test_customer_note_field(self):
        order = Order.objects.create()
        # 检查 customer_node 的值是空字符串
        self.assertEqual(order.customer_note, '')

        # 设置 customer_node 的值，再次检查
        order.customer_note = 'shiyanlou'
        order.save()
        self.assertEqual(order.customer_note, 'shiyanlou')