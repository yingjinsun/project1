from django.contrib import admin
from .models import (
    Category, ProductType,
    Attribute, AttributeValue, Product, ProductVariant
)

from mptt.admin import MPTTModelAdmin

admin.site.register(Category, MPTTModelAdmin)


class ProductVariantInline(admin.TabularInline):
    model = ProductVariant
    fields = ['sku', 'name', 'price', 'quantity', 'quantity_allocated', 'images']


class ProductAdmin(admin.ModelAdmin):
    # 指定 InlineAdmin
    inlines = [
        ProductVariantInline,
    ]


admin.site.register(Product, ProductAdmin)


admin.site.register([
    ProductType,
    Attribute, AttributeValue
])
