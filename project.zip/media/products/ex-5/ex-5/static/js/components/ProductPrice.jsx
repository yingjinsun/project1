import React, { useState, useEffect } from 'react';

export const ProductPrice = function ({ id }) {
  // 定义价格和商品变种的 state
  const [price, setPrice] = useState(0);
  const [variants, setVariants] = useState([]);
  // 定义初始化 state
  const [initialized, setInitialized] = useState(false);

  // 组件挂载或更新后触发
  useEffect(() => {
    if (!initialized) {
      fetch(`/api/products/${id}`)
        .then(response => response.json())
        .then(data => {
          // 将 API 返回的内容设置到state
          setPrice(data.price);
          setVariants(data.variants);
        });
      // 标记完成初始化操作
      setInitialized(true);
    }
  });

  return (
    <div>
      <var className="price h3 text-warning">
        <span>{ price }</span>
      </var>
      <dl className="dlist-inline">
        <dd>
        {/* 迭代返回的商品变种 */}
        { variants.map(variant => (
          <label key={ variant.id } className="form-check form-check-inline">
            {/* 价格写到单选按钮的 dataset，绑定 onClick 事件，点击设置价格 */}
            <input className="form-check-input" type="radio" name="product_variant"
                   value={ variant.id }
                   data-price={ variant.base_price }
                   onClick={ (e) => setPrice(e.target.dataset.price) } />
            <span className="form-check-label">{ variant.name }</span>
          </label>
          )
        ) }
        </dd>
      </dl>
    </div>
  );
};
